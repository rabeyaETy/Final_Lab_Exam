

@extends('layout/employee_navbar')



@section('title')
Home Page
@endsection


@section('head')
Welcome home! {{$username}}{{$type}}
@endsection